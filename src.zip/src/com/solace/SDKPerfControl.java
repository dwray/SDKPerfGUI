package com.solace;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JToggleButton;
import javax.swing.SwingWorker;
import net.miginfocom.swing.MigLayout;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.text.NumberFormatter;

import com.solacesystems.pubsub.sdkperf.RemoteSDKP;

import javax.swing.JSpinner;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SDKPerfControl extends JPanel {

	/**
	 * @author David Wray, Solace Systems
	 *
	 */
	private static final long serialVersionUID = 1L;
	private boolean bEnabled = false;
	private boolean bFast = true;
	private int baseRMI_Port = 10800;
	
	private PersistenceType persistenceType = new PersistenceType();
	
	private String HighSpeedSendRate;
	private String LowSpeedSendRate;
	private String HighSpeedRcvRate;
	private String LowSpeedRcvRate;
	private long ProgressAmount;
	// used to update receive counter in single client mode
	private long Paired_ProgressAmount;

	//TODO change argument names if RMI works...
	public void setProgressAmount(long increment, long paired_increment) {
//		ProgressAmount += increment;
//		if (sdkPerfGUIApp.isSingleClientMode()) {
//			// update receive counter in single client mode
//			Paired_ProgressAmount += paired_increment;
//		}
		if (increment > 0) {
			ProgressAmount = increment;
		}
		if (sdkPerfGUIApp.isSingleClientMode()) {
			// update receive counter in single client mode
			if (paired_increment > 0) {
				Paired_ProgressAmount = paired_increment;
			}
		}
	}
	
	private Process SDKPerfProcess;
	private boolean bPublisher;
	private boolean bSubscriber;
	private boolean bDebug=false;
	private String jarPath;
	JToggleButton tglbtnEnable;
	JButton jbtnFast;
	JButton jbtnPersistenceType;
	
	private Task task;
	private boolean bConnected = false;
	private String ControlName;
	private JFormattedTextField msgCountTextBox;
	private JLabel lblMsgCount;
	private JCheckBox chckbxShowData;
	private JTextField msgSizeField;
	private JLabel lblSize;
	private SDKPerfGUIApp sdkPerfGUIApp = null;
	// paired subscriber is used just to get subscriber settings in single client mode, it's not actually invoked
	private SDKPerfControl pairedSubscriber;
	
	public boolean isFast() {
		return bFast;
	}
	
	public boolean isShowData() {
		return chckbxShowData.isSelected();
	}

	class PersistenceType {
		
		private String[] types = {"direct","nonpersistent","persistent"};
		private String[] labels = {"Direct","-Persist","+Persist"};
		private String[] tooltips = {"Use Direct Messaging","Use Non Persistent  Messaging","Use Persistent Messaging"};
		
		private int currentClientMessagingType = 0;
		
		public String getCurrentButtonLabel() {
			return labels[currentClientMessagingType];
		}
		
		public String getNextButtonLabel() {
			if (currentClientMessagingType < 2) { 
				currentClientMessagingType++;
			} else {
				currentClientMessagingType = 0;
			}
			return labels[currentClientMessagingType];
		}
		
		public String getCurrentToolTip() {
			return tooltips[currentClientMessagingType];
		}
		
		public String getCurrentClientMessagingType() {
			return types[currentClientMessagingType];
		}
	}
	
	class Task extends SwingWorker<Void, Void> {
		/*
		 * Main task. Executed in background thread.
		 */
		@Override
		public Void doInBackground() {
			// wait until connected
			while (!bConnected && SDKPerfProcess.isAlive()) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException Ignore) {
					//  Ignore
				}
			}
			
			while (SDKPerfProcess.isAlive()) {
				//Sleep for a short while to avoid burning CPU while waiting for updates
				try {
					Thread.sleep(500);
				} catch (InterruptedException ignore) {}

				//Update message count
				msgCountTextBox.setValue(new Long(ProgressAmount));
				if (sdkPerfGUIApp.isSingleClientMode()) {
					pairedSubscriber.msgCountTextBox.setValue(new Long(Paired_ProgressAmount));
				}
			}
			SDKPerfProcess = null;
			return null;
		}

		/*
		 * Executed in event dispatching thread
		 */
		@Override
		public void done() {
			bEnabled = false;	
			// reset the button and checkboxes in the event of process termination not via the enable button
			changeControlEnablement(true);
			tglbtnEnable.setSelected(false);
		}
	}
	
	public SDKPerfControl(String CName, boolean isPublisher, SDKPerfGUIApp controller) {
		super();
		sdkPerfGUIApp = controller;
		setBorder(new LineBorder(SystemColor.windowBorder));
		// set the control number - used for sorting out which control displays which output in the output control
		ControlName = CName;
		setPublisher(isPublisher);
		
		// get values from properties file
		Properties prop = new Properties();
		ClassLoader loader = Thread.currentThread().getContextClassLoader();           
		InputStream stream = loader.getResourceAsStream("config.properties");
		try {
			prop.load(stream);
			HighSpeedSendRate = prop.getProperty("HighSpeedSendRate");
			LowSpeedSendRate = prop.getProperty("LowSpeedSendRate");
			HighSpeedRcvRate = prop.getProperty("HighSpeedRcvRate");
			LowSpeedRcvRate = prop.getProperty("LowSpeedRcvRate");
			bDebug = Boolean.parseBoolean(prop.getProperty("debug"));
			stream.close();
		} catch (IOException e1) {
			SDKPerfGUIApp.infoBox(e1.toString(), "Error Starting SDKPerf Process");
		}
		
		// this is used to give the jar path of this jar to the process builder command so it can execute SDKPerf
		String path = SDKPerfControl.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		try {
			jarPath = URLDecoder.decode(path, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		setLayout(new MigLayout("insets 0", "[]2px[142.00][77.00]", "[]2px[]"));
		
		jbtnPersistenceType = new JButton(persistenceType.getCurrentButtonLabel());
		// fix the button size so the layout doesn't keep changing as the button text changes
		jbtnPersistenceType.setMinimumSize(new Dimension(80, 30));
		jbtnPersistenceType.setMaximumSize(new Dimension(80, 30));
		jbtnPersistenceType.setToolTipText(persistenceType.getCurrentToolTip());
		jbtnPersistenceType.addActionListener(new ActionListener() {
		// cycle through the types: direct, nonpersistent, persistent
		public void actionPerformed(ActionEvent e) {
				jbtnPersistenceType.setText(persistenceType.getNextButtonLabel());
				jbtnPersistenceType.setToolTipText(persistenceType.getCurrentToolTip());
			}
		});
		
		tglbtnEnable = new JToggleButton("Enable");
		tglbtnEnable.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String debug;

				if (tglbtnEnable.getSelectedObjects() == null) {
					//disabled stop instance of SKDPerf
					bEnabled = false;
					StopProcess();
					stopMsgCounter();
					// re-enable other buttons/fields
					changeControlEnablement(true);
					//display appropriate tab
					sdkPerfGUIApp.setOutputDisplayTab(ControlName,bPublisher);
				} else {
					// validate all inputs 
					String errorString = validateAllFreeTextInputs();
					if (errorString.length() > 0) {
						//display errors and exit
						SDKPerfGUIApp.infoBox(errorString,"Argument Validation Error");
						tglbtnEnable.setSelected(false);
						return;
					}
					//enabled start instance of SDKPerf
					bEnabled = true;
					// shouldn't be able to get here with a process but still
					StopProcess();
					StartProcess();
					launchSDKPerf();		
					// disable other buttons
					changeControlEnablement(false);
				}
			}

		});
		add(tglbtnEnable, "cell 0 0,aligny center");
		add(jbtnPersistenceType, "flowx,cell 1 0,aligny center");
				
		lblMsgCount = new JLabel("Count");
		add(lblMsgCount, "cell 0 1,alignx center");
		
		msgCountTextBox = new JFormattedTextField(NumberFormat.getIntegerInstance());
		msgCountTextBox.setHorizontalAlignment(SwingConstants.RIGHT);
		msgCountTextBox.setBackground(SystemColor.window);
		msgCountTextBox.setEditable(false);
		msgCountTextBox.setText("0");
		add(msgCountTextBox, "cell 1 1,growx");
		msgCountTextBox.setColumns(10);
		
		jbtnFast = new JButton("Fast");
		jbtnFast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bFast = !bFast;
				if (bFast) {
					jbtnFast.setText("Fast");
				} else {
					jbtnFast.setText("Slow");
				}
			}
		});
		add(jbtnFast, "cell 1 0,aligny center");
		
		// publishers have message size, subscribers have show payload
		if (bPublisher) {
			lblSize = new JLabel("Size");
			add(lblSize, "cell 2 0,alignx center,aligny center");

			msgSizeField = new JTextField("10");
			msgSizeField.setColumns(8);
			msgSizeField.setMinimumSize(new Dimension(80, 20));
			msgSizeField.setHorizontalAlignment(SwingConstants.LEFT);

			add(msgSizeField, "cell 2 1,growx");
		}else {
			chckbxShowData = new JCheckBox("Show");
			add(chckbxShowData, "cell 2 1,aligny top");			
		}
	}

	public void StopProcess() {
		if (SDKPerfProcess != null) {			
			// kill with RMI
			try {
				Registry registry = LocateRegistry.getRegistry(getRMIRegistryPort());
				RemoteSDKP stub = (RemoteSDKP) registry.lookup("RemoteSDKP");
				stub.doRemoteShutdown();
			} catch (java.rmi.UnmarshalException ignore) {
				//since we are doing a shutdown by calling system.exit the sockets close and we get an UnmarshallException - since it's a void method there is no return so it's safe to ignore this
				// terminate the old fashioned way...
				SDKPerfProcess.destroy();
			} catch (RemoteException e) {
				e.printStackTrace();
				// terminate the old fashioned way...
				SDKPerfProcess.destroy();
			} catch (NotBoundException e) {
				e.printStackTrace();
				// terminate the old fashioned way...
				SDKPerfProcess.destroy();
			} 
		}
	}
	
	protected void StartProcess() {
		//build args
		//common: shell, router, user@vpn
		ArrayList<String> Args  = new ArrayList<String>();
		Args.add("java");
		// rmi stuff
		Args.add("-Dcom.sun.management.jmxremote");
		String rmiPort = Integer.toString(getRMIPort());
		Args.add("-Dcom.sun.management.jmxremote.port="+rmiPort);
		Args.add("-Dcom.sun.management.jmxremote.authenticate=false");
		Args.add("-Dcom.sun.management.jmxremote.ssl=false");
		
		Args.add("-cp");
		Args.add(jarPath);
		Args.add("-Xms512m");
		Args.add("-Xmx1024m");
		Args.add("com.solacesystems.pubsub.sdkperf.SDKPerf_java_rmi");
		Args.add("-cip");
		Args.add(sdkPerfGUIApp.getRouterAddress());
		Args.add("-cu");
		Args.add(sdkPerfGUIApp.getUser()+"@"+sdkPerfGUIApp.getVPN());
		if (sdkPerfGUIApp.getPassword().length() > 0) {
			Args.add("-cp");
			Args.add(new String(sdkPerfGUIApp.getPassword()));
		}
		if (sdkPerfGUIApp.isOrderCheck()) {
			Args.add("-oc");
		}
		
		if (bPublisher){
			if (sdkPerfGUIApp.isTopic(ControlName)) {
				Args.add("-ptl");
			} else {
				Args.add("-pql");
			}				
			Args.add(sdkPerfGUIApp.getMessageDestination(ControlName));
			Args.add("-mn");
			// has been already validated when enable button clicked
			Args.add(sdkPerfGUIApp.getMessageCount(bFast));
			Args.add("-msa");
			// has been already validated when enable button clicked
			Args.add(msgSizeField.getText());
			Args.add("-mr");
			if (bFast) {
				Args.add(sdkPerfGUIApp.getFastPublishSpeed());
			} else {
				Args.add(sdkPerfGUIApp.getSlowPublishSpeed());
			}
			if (sdkPerfGUIApp.isDTO()) {
				Args.add("-pto");
			}
			if (sdkPerfGUIApp.isRequestReply()) {
				Args.add("-prq");
			}
			//quiet mode
			if (sdkPerfGUIApp.isQuiet(true)) {
				Args.add("-q");
			}
		} 
		if (bSubscriber || sdkPerfGUIApp.isSingleClientMode()) { // subscriber or single client mode
			//note browsing only possible if it's a queue, so isTopic also returns false when browser is selected (i.e. it's a queue)
			if (sdkPerfGUIApp.isTopic(ControlName)) {
				Args.add("-stl");
			} else {
				Args.add("-sql");
			}	
			Args.add(sdkPerfGUIApp.getMessageDestination(ControlName));
			if (sdkPerfGUIApp.isReplyMode()) {
				Args.add("-cm=reply");
			}
			// this seems to fail in queue browser mode, not sure why, for now only use if not browsing
			if (sdkPerfGUIApp.isProvisionEndpoints() &&!sdkPerfGUIApp.isBrowser(ControlName)) {
				Args.add("-pe");
				// let's give a permission of delete to keep things simple
				Args.add("-pep");
				Args.add("d");
				// set queue exclusivity
				Args.add("-pea");
				if (sdkPerfGUIApp.isProvisionNonExclusive()) {
					Args.add("0");
				} else {
					Args.add("1");
				}
			}
			// if browsing enabled - note browsing only possible if it's a queue, so isTopic returns false when browser is selected (i.e. it's a queue)
			if(sdkPerfGUIApp.isBrowser(ControlName)) {
				Args.add("-qb");
			}
			
			if (bSubscriber) { //native subscriber
				if (bFast) {
					// a fast subscriber might still have a non-zero subscriber delay, 0 is the default so safe to always add
					Args.add("-sd");
					Args.add(sdkPerfGUIApp.getFastSubscriberDelay());
				}  else {
					Args.add("-sd");
					Args.add(sdkPerfGUIApp.getSlowSubscriberDelay());
				}
				//quiet mode
				if (sdkPerfGUIApp.isQuiet(false)) {
					Args.add("-q");
				}
				if (chckbxShowData.isSelected()) {
					Args.add("-md");
				}
			} else { //paired subscriber in Single Client mode, gets client settings from the paired subscriber not from itself
				if (pairedSubscriber.bFast) {
					// a fast subscriber might still have a non-zero subscriber delay, 0 is the default so safe to always add
					Args.add("-sd");
					Args.add(sdkPerfGUIApp.getFastSubscriberDelay());
				}  else {
					Args.add("-sd");
					Args.add(sdkPerfGUIApp.getSlowSubscriberDelay());
				}
				// don't need to add quiet mode for subscriber as will be set in the publisher settings
				if (pairedSubscriber.chckbxShowData.isSelected()) {
					Args.add("-md");
				}
			}
		}
		// it's safe to always add this since direct is the default we are just be explicit about it
		Args.add("-mt");
		Args.add(persistenceType.getCurrentClientMessagingType());
		
		// add latency settings
		if (sdkPerfGUIApp.isEnableLatencyMeasurement()) {
			Args.add("-l");
			// default latency granularity is 0 so we can safely add any value 0 or above
			Args.add("-lg");
			Args.add(sdkPerfGUIApp.getLatencyGranularity());
			if (sdkPerfGUIApp.isPrintLatencyStats()) {
				Args.add("-lat");
			}
		}
		
		if (bDebug) {
			SDKPerfGUIApp.infoBox(Args.toString(), "DEBUG");		
		}
		try {
			//Apparently using new String [0] is actually more efficient, I still don't like it.
			ProcessBuilder pb = new ProcessBuilder(Args.toArray(new String[Args.size()]));
			
			pb.redirectErrorStream(true);
			
			// set connected property for message count box
			bConnected = false;

			SDKPerfProcess =  pb.start();
			//set up callbacks for connection and amount of messages published
			Method connectedMethod = this.getClass().getMethod("setConnected");
			Method updateProgressMethod = this.getClass().getMethod("setProgressAmount", long.class, long.class);
			
			//create string of arguments for top of text window
			String builtCommand="";
			Iterator<String> iterator = Args.iterator();
			while(iterator.hasNext()) {
				builtCommand += iterator.next() + " ";
			}

			sdkPerfGUIApp.showClientTextStream(SDKPerfProcess, connectedMethod, updateProgressMethod, this, ControlName, bPublisher, builtCommand);

		} catch (Exception e) {
			SDKPerfGUIApp.infoBox(e.toString(), "Error Starting SDKPerf Process");
		}
	}

	public int getRMIPort() {
		int ClientNumber= 0;
		
		if (bPublisher) {
			ClientNumber = Integer.parseInt(ControlName.substring(9)) - 1;
		} else {
			ClientNumber = Integer.parseInt(ControlName.substring(10)) - 1+50;
		}
		return ClientNumber+baseRMI_Port;
	}
	public int getRMIRegistryPort() {
		
		return getRMIPort()-100;
	}

	public void setConnected() {
		bConnected=true;
	}

	public void setPublisher(boolean b) {
		bPublisher = b;
		bSubscriber = !b;	
	}
	
	private void stopMsgCounter() {
		task.cancel(false);
	}

	private void launchSDKPerf() {	
		// reset message count
		ProgressAmount = 0;		
		if (sdkPerfGUIApp.isSingleClientMode()) {
			Paired_ProgressAmount = 0;
		}
		msgCountTextBox.setValue(new Long(0));

		task = new Task();
	    task.execute();
	}

	private void changeControlEnablement(boolean bEnablement) {
		if (bPublisher) {
			msgSizeField.setEnabled(bEnablement);
			lblSize.setEnabled(bEnablement);
		} else {
			chckbxShowData.setEnabled(bEnablement);
		}
		jbtnPersistenceType.setEnabled(bEnablement);
		jbtnFast.setEnabled(bEnablement);
	}
	private String validateAllFreeTextInputs() {
		String errorString = "";
		String LF = System.getProperty("line.separator");

		// validate common fields
/*		Leaving these as place holders, no obvious validation possible
		sdkPerfGUIApp.getRouterAddress();
		sdkPerfGUIApp.getUser();
		sdkPerfGUIApp.getPassword();
		sdkPerfGUIApp.getVPN();
		sdkPerfGUIApp.isOrderCheck();
		sdkPerfGUIApp.isTopic();
*/		
		// Validate common fields or overrides
		if (sdkPerfGUIApp.getMessageDestination(ControlName).length() == 0) {
			String specificClient = "";
			if (sdkPerfGUIApp.isOverrides()) {
				specificClient = " for "+ControlName+" on the Overrides tab";
			}
			errorString += "Please enter a message destination"+specificClient+"."+LF;
		}

		// validate publisher specific fields
		if (bPublisher) {
			if (!validatePositiveNumericField(sdkPerfGUIApp.getMessageCount(bFast), false)) {
				errorString += "Please enter a positive non-zero message count (numeric)."+LF;
			}
					
			if (!validatePositiveNumericField(sdkPerfGUIApp.getFastPublishSpeed(), false))  {
				errorString += "Please enter a positive non-zero publisher fast speed (numeric)."+LF;
			}
			if (!validatePositiveNumericField(sdkPerfGUIApp.getSlowPublishSpeed(), false))  {
				errorString += "Please enter a positive non-zero publisher slow speed (numeric)."+LF;
			}
			// message size field is on the control not the main app
			if (!validatePositiveNumericField(msgSizeField.getText(), false)) {
				errorString += "Please enter a positive non-zero message size (numeric)."+LF;
			}
		} else {
			// validate consumer specific fields
			if (!validatePositiveNumericField(sdkPerfGUIApp.getFastSubscriberDelay(), true))  {
				errorString += "Please enter a positive (can be zero) fast subscriber delay (numeric)."+LF;
			}
			if (!validatePositiveNumericField(sdkPerfGUIApp.getSlowSubscriberDelay(), false))  {
				errorString += "Please enter a positive non-zero slow subscriber delay (numeric)."+LF;
			}
		}
		
		// validate latency fields if latency is enabled
		if (sdkPerfGUIApp.isEnableLatencyMeasurement()) {
			// no validation for a check box
		//	sdkPerfGUIApp.isPrintLatencyStats();		
			if (!validatePositiveNumericField(sdkPerfGUIApp.getLatencyGranularity(), true))  {
				errorString += "Please enter a valid (can be zero) Latency Granularity (numeric)."+LF;
			}
		}
		return errorString;
	}

	private boolean validatePositiveNumericField(String testString, boolean canBeZero) {
		long longTest;
		try {
			longTest = Long.parseLong(testString);
			if (longTest < 1 && !canBeZero) {
				return false;
			} else if (longTest < 0) {
				return false;
			}
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	public void addPairedSubscriber(SDKPerfControl subscriber) {
		// paired subscriber is used just to get subscriber settings in single client mode
		pairedSubscriber = subscriber;	
	}

	public void disableEnableButton(boolean b) {
		tglbtnEnable.setEnabled(!b);
		jbtnPersistenceType.setEnabled(!b);
	}
}
